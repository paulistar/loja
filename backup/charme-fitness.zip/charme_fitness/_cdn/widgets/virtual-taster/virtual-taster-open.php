<button class="virtual-taster__open js_open" type="button">
    <img src="<?= BASE; ?>/_cdn/widgets/virtual-taster/images/hanger.png" alt="Provador Virtual" title="Provador Virtual"/>
    <span>Provador Virtual</span>
</button>