<?php if (!empty($pdt_type) && !empty($pdt_measurement)): ?>
    <button class="measurement-chart__open js_measurement_chart_open" type="button">
        <img src="<?= BASE; ?>/_cdn/widgets/measurement-chart/images/ruler.png" alt="Tabela de Medidas" title="Tabela de Medidas"/>
        <span>Tabela de Medidas</span>
    </button>
<?php endif; ?>