<?php

if (!$WorkControlDefineConf):
    /*
      AGENCY DATA
      Dados da sua agência web
     */
    define('AGENCY_CONTACT', ''); //Nome do contato
    define('AGENCY_EMAIL', ''); //E-mail de contato
    define('AGENCY_PHONE', ''); //Telefone de contato
    define('AGENCY_URL', ''); //URL completa do seu site/portfolio
    define('AGENCY_NAME', ''); //Nome da sua agência web
    define('AGENCY_ADDR', ''); //Endereço da sua agência web (RUA, NÚMERO)
    define('AGENCY_CITY', '');  //Endereço da sua agência web (CIDADE)
    define('AGENCY_UF', '');  //Endereço da sua agência web (UF DO ESTADO)
    define('AGENCY_ZIP', '');  //Endereço da sua agência web (CEP)
    define('AGENCY_COUNTRY', '');  //Endereço da sua agência web (PAÍS)
endif;

